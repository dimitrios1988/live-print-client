export interface IEvent {
  name: string;
  name_for_printing: string;
  allow_reprinting: boolean;
  id: number;
}
