export enum RunnerPrintStatus {
  NOT_PRINTED = 'Ok',
  ALREADY_PRINTED = 'AlreadyPrinted',
  NOT_FOUND = 'NotFound',
}
