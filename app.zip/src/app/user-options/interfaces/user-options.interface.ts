export interface UserOptions {
  printNumbers: [true?];
  printTickets: [true?];
  continuousPrint: [true?];
}
