export interface SetRunnerPrintedResp {
  '0': number;
}
