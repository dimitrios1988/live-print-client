export interface IGetRunnerIdCmd {
  '0(runner)': {
    bib: number;
  };
  '1(event)': {
    id: number;
  };
}
