export interface IGetRunnerIdResponse {
  '0': number;
  '1': number;
}
