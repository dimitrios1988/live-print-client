export interface SetRunnerPrintedCmd {
  '0(runner)': _0runner;
}

interface _0runner {
  id: number;
  is_printed: boolean;
}
