export interface ISettings {
  numberPrinter: any;
  ticketPrinter: any;
  apiAddress: string;
  appName: string;
}
